# -*- coding: utf-8 -*-
"""
Created on Tue Nov  8 16:57:24 2022

Data processing  script

@author: CVed
"""

import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import numpy as np

#read the file
crop=pd.read_csv('CropProductionStatistics.csv')

#check for null values
print('null value in % :\n',crop.isnull().sum()*100/len(crop))

#trim/Remove spaces in crop names
crop['Crop']=crop['Crop'].str.strip()

#drop the Null values found in production column ,1.5% of the rows.
crop.dropna(subset=['Production'],axis=0,inplace=True)


#Categorizing crops for better visualization experience
cc=crop['Crop']



def cat_crop(cc):
    for i in ['Rice','Maize','Wheat','Barley','Varagu','Other Cereals & Millets','Ragi','Small millets','Bajra','Jowar']:
        if cc==i:
            return 'Cereal'
    for i in ['Moong','Moong(Green Gram)','Urad','Arhar/Tur','Peas & beans','Masoor',
              'Other Kharif pulses','other misc. pulses','Ricebean (nagadal)',
              'Rajmash Kholar','Lentil','Samai','Blackgram','Korra','Cowpea(Lobia)',
              'Other  Rabi pulses','Other Kharif pulses','Peas & beans (Pulses)']:
        if cc==i:
            return 'Pulses'
    for i in ['Peach','Apple','Litchi','Pear','Plums','Ber','Sapota','Lemon','Pome Granet',
               'Other Citrus Fruit','Water Melon','Jack Fruit','Grapes','Pineapple','Orange',
               'Pome Fruit','Citrus Fruit','Other Fresh Fruits','Mango','Papaya','Coconut','Banana']:
        if cc==i:
            return 'Fruits'
    for i in ['Bean','Lab-Lab','Moth','Guar seed','Tapioca','Soyabean','Horse-gram','Gram']:
        if cc==i:
            return 'Beans'
    for i in ['Turnip','Peas','Beet Root','Carrot','Yam','Ribed Guard','Ash Gourd','Pump Kin','Redish','Snak Guard','Bottle Gourd',
              'Bitter Gourd','Cucumber','Drum Stick','Cauliflower','Beans & Mutter(Vegetable)','Cabbage',
              'Bhindi','Tomato','Brinjal','Khesari','Peas  (vegetable)','Sweet potato','Potato','Onion','Other Vegetables']:
        if cc==i:
            return 'Vegetables'
    for i in ['Perilla','Colocosia','Ginger','Cardamom','Black pepper','Dry ginger','Garlic','Coriander','Turmeric','Dry chillies']:
        if cc==i:
            return 'Species'
    for i in ['Jobster','Cond-spcs other']:
        if cc==i:
            return 'Other'
    for i in ['other fibres','Kapas','Jute & mesta','Jute','Mesta','Cotton(lint)']:
        if cc==i:
            return 'fibres'
    for i in ['Arcanut (Processed)','Atcanut (Raw)','Cashewnut Processed','Cashewnut Raw','Cashewnut','Arecanut','Groundnut']:
        if cc==i:
            return 'Nuts'
    for i in ['Rubber']:
        if cc==i:
            return 'Natural Polymer'
    for i in ['Coffee']:
        if cc== i:
            return 'Coffee'
    for i in ['Tea']:
        if cc==i:
            return 'Tea'
    for i in ['Total foodgrain']:
        if cc==i:
            return 'Total foodgrain'
    for i in ['Pulses total']:
        if cc==i:
            return 'Pulses total'
    for i in ['Oilseeds total']:
        if cc==i:
            return 'Oilseeds total'
    for i in ['Paddy']:
        if cc==i:
            return 'Paddy'
    for i in ['other oilseeds','Safflower','Niger seed','Castor seed','Linseed','Sunflower','Rapeseed &Mustard','Sesamum']:
        if cc==i:
            return 'Oilseeds'
    for i in ['Sannhamp']:
        if cc==i:
            return 'Fertile Plant'
    for i in ['Tobacco']:
        if cc==i:
            return 'Commercial'
    for i in ['Sugarcane']:
        if cc==i:
            return 'Sugarcane'
    for i in ['Other Dry Fruit']:
           if cc==i:
               return 'Other Dry Fruit'    
        
crop['cat_crop']=crop['Crop'].apply(cat_crop)


#Box Plot for Crop Category
df=crop[['Production','cat_crop']]
df=pd.DataFrame(df)
sns.boxplot(y='Production', x='cat_crop',data=df)
plt.xticks(rotation=90)
plt.ylabel('Production')



#Box Plot for Fruits
df=crop[['Production','cat_crop','Crop']]
df=crop[crop['cat_crop']=='Fruits']
sns.boxplot(y='Production', x='Crop',data=df)
plt.xticks(rotation=90)
plt.ylabel('Production')


crop.to_csv('newdata.csv',index=False)